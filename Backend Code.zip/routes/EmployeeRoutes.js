const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');

// Create employee
router.post('/', async (req, res) => {
  try {
    const { name, designation, experience, department, salary } = req.body;
    if (!name || !designation || experience === undefined) {
      return res.status(400).json({ message: 'name, designation and experience are required.' });
    }

    const employee = new Employee({ name, designation, experience, department, salary });
    await employee.save();
    res.status(201).json({ message: 'Employee created', employee });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// List employees
router.get('/', async (req, res) => {
  try {
    const employees = await Employee.find().sort({ createdAt: -1 });
    res.status(200).json(employees);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
